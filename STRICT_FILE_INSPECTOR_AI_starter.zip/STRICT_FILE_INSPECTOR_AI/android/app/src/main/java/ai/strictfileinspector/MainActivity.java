package ai.strictfileinspector;

import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.content.ContentResolver;
import android.graphics.Typeface;
import java.io.InputStream;
import java.security.MessageDigest;

public class MainActivity extends Activity {
    private static final int PICK_FILE = 41;
    private TextView status;
    private static final String CHANNEL = "scan_results";

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        createChannel();
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(36, 48, 36, 24);
        root.setBackgroundColor(0xFF08110D);
        TextView title = new TextView(this);
        title.setText("STRICT FILE INSPECTOR AI");
        title.setTextColor(0xFF5FE0A0);
        title.setTextSize(22);
        title.setTypeface(null, Typeface.BOLD);
        root.addView(title);
        TextView subtitle = new TextView(this);
        subtitle.setText("Defensive file inspection • prototype");
        subtitle.setTextColor(0xFFB6C8BD);
        subtitle.setPadding(0, 12, 0, 28);
        root.addView(subtitle);
        Button choose = new Button(this);
        choose.setText("เลือกไฟล์เพื่อตรวจสอบ");
        root.addView(choose);
        status = new TextView(this);
        status.setText("ไฟล์จะถูกเลือกผ่านหน้าต่างของ Android เท่านั้น");
        status.setTextColor(0xFFFFFFFF);
        status.setPadding(0, 24, 0, 24);
        root.addView(status);
        TextView disclaimer = new TextView(this);
        disclaimer.setText("ข้อจำกัด: รุ่นเริ่มต้นนี้สร้าง SHA-256 และตรวจขนาดไฟล์เท่านั้น ยังไม่มีฐานข้อมูลมัลแวร์หรือ AI และไม่สามารถยืนยันว่าไฟล์ปลอดภัย");
        disclaimer.setTextColor(0xFFFFD58A);
        root.addView(disclaimer);
        choose.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("*/*");
            startActivityForResult(intent, PICK_FILE);
        });
        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        setContentView(scroll);
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "ผลการตรวจไฟล์", NotificationManager.IMPORTANCE_DEFAULT);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_FILE || resultCode != RESULT_OK || data == null) return;
        Uri uri = data.getData();
        if (uri == null) return;
        try {
            String name = getName(uri);
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            long total = 0;
            byte[] buf = new byte[8192];
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                if (in == null) throw new Exception("เปิดไฟล์ไม่ได้");
                int n;
                while ((n = in.read(buf)) != -1) {
                    total += n;
                    if (total > 50L * 1024 * 1024) throw new Exception("ไฟล์เกินขีดจำกัดเดโม 50 MB");
                    digest.update(buf, 0, n);
                }
            }
            StringBuilder hex = new StringBuilder();
            for (byte b : digest.digest()) hex.append(String.format("%02x", b & 0xff));
            status.setText("ตรวจเบื้องต้นเสร็จแล้ว\nชื่อ: " + name + "\nขนาด: " + total + " bytes\nSHA-256: " + hex + "\n\nนี่ไม่ใช่ผลยืนยันว่าไฟล์ปลอดภัย");
            Toast.makeText(this, "สร้างค่าแฮชเสร็จแล้ว", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            status.setText("ตรวจไม่ได้: " + e.getMessage());
        }
    }

    private String getName(Uri uri) {
        String result = "selected-file";
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int index = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) result = c.getString(index);
            }
        } catch (Exception ignored) {}
        return result;
    }
}
