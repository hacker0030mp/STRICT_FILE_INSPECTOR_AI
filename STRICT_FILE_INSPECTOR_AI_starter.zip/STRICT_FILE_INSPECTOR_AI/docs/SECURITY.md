# Security boundaries

- Use Android's Storage Access Framework / document picker for user-selected files.
- Never execute a file being inspected.
- Do not claim “clean” based only on file extension, magic bytes, or SHA-256.
- Keep uploaded file contents out of logs by default.
- Apply size limits, rate limits, authentication, and server-side authorization before production.
- Keep API keys, private keys, service-account JSON, and signing secrets out of GitHub.
- Firebase client configuration is not a substitute for Firestore/Storage Security Rules.
- Verify Firebase ID tokens on the backend before trusting a user identity.
- Do not expose an unrestricted file-upload endpoint. If server-side scanning is added, use a quarantined, isolated processing environment and strict retention/deletion policies.
- Use HTTPS in production.
- Community/chat features require moderation, abuse reporting, and access controls before public launch.
