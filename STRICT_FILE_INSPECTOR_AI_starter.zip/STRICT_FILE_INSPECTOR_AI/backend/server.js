'use strict';
const express = require('express');
const helmet = require('helmet');
const app = express();
const PORT = Number(process.env.PORT || 3000);
app.disable('x-powered-by');
app.use(helmet());
app.use(express.json({limit: '32kb'}));
app.get('/api/health', (_req, res) => res.json({ok:true, service:'strict-file-inspector-api', mode:'starter', scanEngineConnected:false}));
app.post('/api/scan/metadata', (req, res) => {
  const {fileName, size, sha256} = req.body || {};
  if (typeof fileName !== 'string' || fileName.length < 1 || fileName.length > 255)
    return res.status(400).json({error:'fileName must be a string up to 255 characters'});
  if (!Number.isSafeInteger(size) || size < 0 || size > 50 * 1024 * 1024)
    return res.status(400).json({error:'size must be between 0 and 50 MiB'});
  if (typeof sha256 !== 'string' || !/^[a-f0-9]{64}$/i.test(sha256))
    return res.status(400).json({error:'sha256 must be a 64-character hex digest'});
  // Metadata-only demonstration. Do not trust client-reported fields as a verdict.
  return res.status(202).json({accepted:true, status:'metadata_received_demo_only', message:'No file bytes were uploaded and no malware scan was performed.'});
});
app.use((err, _req, res, _next) => {
  res.status(400).json({error:'Invalid request'});
});
app.listen(PORT, () => console.log(`API listening on port ${PORT}`));
